import React from 'react';
import { Section } from './components/Section';
import { Tooltip } from './components/Tooltip';
import { MoleculeH2O, LewisH2O, BondTypesVisual, PolarityVisual } from './components/MoleculeVisuals';
import { SimulationSection } from './components/Simulation';
import { PracticeQuiz } from './components/PracticeQuiz';
import { EducationalGame } from './components/EducationalGame';
import { Atom, Droplets, Zap, BookOpen, AlertCircle, ArrowRight } from 'lucide-react';

export default function App() {
  return (
    <div className="min-h-screen bg-slate-50 pb-20">
      {/* Header */}
      <header className="bg-teal-700 text-white sticky top-0 z-40 shadow-md">
        <div className="max-w-3xl mx-auto px-4 py-4 flex items-center gap-3">
          <Atom className="w-8 h-8 text-teal-200" />
          <div>
            <h1 className="text-xl md:text-2xl font-bold tracking-tight">Materi Ikatan Kovalen</h1>
            <p className="text-teal-200 text-xs md:text-sm">Kimia SMA Kelas X</p>
          </div>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 py-8 space-y-6">
        
        {/* 2.1 Pengantar */}
        <Section number="2.1" title="Pengantar Ikatan Kovalen" defaultOpen={true}>
          <div className="prose prose-slate max-w-none">
            <div className="flex flex-col md:flex-row gap-6 items-center mb-6">
              <div className="flex-1">
                <p className="mb-4">
                  Pernahkah kamu berpikir, mengapa air (H₂O) berbentuk cair pada suhu ruang, sedangkan oksigen (O₂) berbentuk gas yang kita hirup? Keduanya tersusun dari atom-atom non-logam yang saling berpegangan erat.
                </p>
                <div className="bg-blue-50 p-4 rounded-lg border-l-4 border-blue-500">
                  <h3 className="text-blue-800 font-bold mb-2 flex items-center gap-2">
                    <AlertCircle className="w-4 h-4" /> Pertanyaan Pemantik
                  </h3>
                  <ul className="list-disc ml-5 space-y-2 text-blue-900 text-sm">
                    <li>Mengapa atom-atom harus bergabung membentuk molekul, tidak sendirian saja?</li>
                    <li>Bagaimana cara atom non-logam "berbagi" elektron tanpa saling melepaskan?</li>
                  </ul>
                </div>
              </div>
              <div className="flex-shrink-0">
                <MoleculeH2O />
              </div>
            </div>
          </div>
        </Section>

        {/* 2.2 Elektron Valensi */}
        <Section number="2.2" title="Elektron Valensi & Kestabilan Atom">
          <div className="space-y-4 text-slate-700">
            <p>
              Setiap atom memiliki <Tooltip term="Elektron Valensi" definition="Elektron yang terletak pada kulit terluar atom dan terlibat dalam pembentukan ikatan kimia." />. Ini adalah kunci interaksi antar atom.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 my-4">
              <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm">
                <h4 className="font-bold text-teal-600 mb-2">Aturan Duplet</h4>
                <p className="text-sm">Konfigurasi stabil dengan <strong>2 elektron</strong> valensi (seperti Helium). Berlaku untuk atom kecil seperti Hidrogen (H).</p>
              </div>
              <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm">
                <h4 className="font-bold text-teal-600 mb-2">Aturan Oktet</h4>
                <p className="text-sm">Konfigurasi stabil dengan <strong>8 elektron</strong> valensi (seperti Gas Mulia lainnya). Kebanyakan atom mengejar kondisi ini.</p>
              </div>
            </div>
            
            <p className="text-sm italic text-slate-500">
              "Atom-atom yang tidak stabil akan berusaha mencapai kestabilan gas mulia dengan cara berikatan."
            </p>
          </div>
        </Section>

        {/* 2.3 Pengertian */}
        <Section number="2.3" title="Pengertian Ikatan Kovalen">
          <div className="space-y-4">
            <div className="bg-teal-50 p-5 rounded-xl border border-teal-100">
              <h3 className="font-bold text-teal-800 text-lg mb-2">Definisi</h3>
              <p className="text-teal-900 leading-relaxed">
                <strong>Ikatan Kovalen</strong> adalah ikatan yang terbentuk akibat penggunaan bersama pasangan elektron oleh dua atom atau lebih (biasanya sesama non-logam).
              </p>
            </div>

            <h4 className="font-semibold text-slate-800 mt-6 mb-3">Perbandingan dengan Ikatan Ion</h4>
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left text-slate-600 border-collapse">
                <thead className="bg-slate-100 text-slate-800 uppercase text-xs">
                  <tr>
                    <th className="px-4 py-3 rounded-tl-lg">Fitur</th>
                    <th className="px-4 py-3">Ikatan Kovalen</th>
                    <th className="px-4 py-3 rounded-tr-lg">Ikatan Ion</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-slate-100">
                    <td className="px-4 py-3 font-medium">Proses</td>
                    <td className="px-4 py-3 bg-teal-50 text-teal-900 font-medium">Sharing Elektron</td>
                    <td className="px-4 py-3">Serah Terima Elektron</td>
                  </tr>
                  <tr className="border-b border-slate-100">
                    <td className="px-4 py-3 font-medium">Penyusun</td>
                    <td className="px-4 py-3">Non-logam + Non-logam</td>
                    <td className="px-4 py-3">Logam + Non-logam</td>
                  </tr>
                  <tr>
                    <td className="px-4 py-3 font-medium">Contoh</td>
                    <td className="px-4 py-3">Air (H₂O), Metana (CH₄)</td>
                    <td className="px-4 py-3">Garam Dapur (NaCl)</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </Section>

        {/* 2.4 Struktur Lewis */}
        <Section number="2.4" title="Struktur Lewis">
          <div className="space-y-6">
            <p>
              Struktur Lewis menggambarkan bagaimana elektron valensi didistribusikan di sekitar atom dalam sebuah molekul.
            </p>

            <div className="flex flex-col md:flex-row gap-6 items-center bg-white p-4 rounded-xl border border-slate-200">
               <div className="flex-1">
                 <h4 className="font-bold text-slate-800 mb-2 flex items-center gap-2">
                   <BookOpen className="w-4 h-4 text-teal-500" /> Langkah Menggambar:
                 </h4>
                 <ol className="list-decimal list-inside space-y-2 text-sm text-slate-600">
                   <li>Hitung total elektron valensi semua atom.</li>
                   <li>Tentukan atom pusat (biasanya yang jumlahnya paling sedikit).</li>
                   <li>Buat ikatan tunggal antara atom pusat dan atom luar.</li>
                   <li>Lengkapi oktet atom luar terlebih dahulu.</li>
                   <li>Sisa elektron ditaruh di atom pusat.</li>
                 </ol>
               </div>
               <div className="flex-shrink-0">
                  <LewisH2O />
               </div>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-center text-sm">
                <div className="p-2 bg-slate-50 rounded border">H₂</div>
                <div className="p-2 bg-slate-50 rounded border">NH₃</div>
                <div className="p-2 bg-slate-50 rounded border">CO₂</div>
                <div className="p-2 bg-slate-50 rounded border">CH₄</div>
            </div>
          </div>
        </Section>

        {/* 2.5 Jenis Ikatan */}
        <Section number="2.5" title="Jenis Ikatan Kovalen">
          <p className="mb-4 text-slate-700">
            Berdasarkan jumlah pasangan elektron yang digunakan bersama, ikatan kovalen dibagi menjadi tiga:
          </p>
          <BondTypesVisual />
        </Section>

        {/* 2.6 Polar & Nonpolar */}
        <Section number="2.6" title="Kovalen Polar & Nonpolar">
          <div className="space-y-4">
             <div className="flex items-start gap-3 p-4 bg-orange-50 rounded-lg border border-orange-100">
                <Zap className="w-5 h-5 text-orange-500 mt-1 flex-shrink-0" />
                <div>
                  <h4 className="font-bold text-orange-800">Konsep Kuncinya: Keelektronegatifan</h4>
                  <p className="text-sm text-orange-900 mt-1">
                    Keelektronegatifan adalah kemampuan atom untuk menarik elektron ikatan ke arah dirinya.
                  </p>
                </div>
             </div>

             <div className="grid md:grid-cols-2 gap-6 mt-4">
                <div>
                   <h5 className="font-bold text-slate-800 mb-2 border-b pb-1">Ikatan Nonpolar</h5>
                   <ul className="list-disc list-inside text-sm text-slate-600 space-y-1">
                      <li>Beda keelektronegatifan = 0 (atau sangat kecil).</li>
                      <li>Elektron tersebar merata.</li>
                      <li>Biasanya terjadi pada atom sejenis (misal H-H).</li>
                   </ul>
                </div>
                <div>
                   <h5 className="font-bold text-slate-800 mb-2 border-b pb-1">Ikatan Polar</h5>
                   <ul className="list-disc list-inside text-sm text-slate-600 space-y-1">
                      <li>Ada perbedaan keelektronegatifan.</li>
                      <li>Terbentuk kutub positif (δ⁺) dan negatif (δ⁻).</li>
                      <li>Contoh: H-Cl (Cl lebih kuat menarik elektron).</li>
                   </ul>
                </div>
             </div>
          </div>
        </Section>

        {/* 2.7 Kepolaran Molekul */}
        <Section number="2.7" title="Kepolaran Molekul">
           <div className="space-y-4">
              <p className="text-slate-700">
                Apakah molekul yang punya ikatan polar pasti bersifat polar? <span className="font-bold text-teal-700">Belum tentu!</span> Kita harus melihat bentuk molekulnya (simetris atau asimetris).
              </p>

              <PolarityVisual />

              <div className="bg-slate-800 text-slate-200 p-4 rounded-lg text-sm">
                <span className="font-bold text-teal-400">Tips:</span> Molekul dikatakan <strong>Nonpolar</strong> jika bentuknya simetris dan resultan momen dipolnya = 0 (saling meniadakan), contohnya CO₂ dan CH₄.
              </div>

              <div className="flex gap-2 mt-4 overflow-x-auto pb-2">
                 <span className="px-3 py-1 bg-teal-100 text-teal-800 rounded-full text-xs font-semibold whitespace-nowrap">H₂O (Polar)</span>
                 <span className="px-3 py-1 bg-slate-200 text-slate-700 rounded-full text-xs font-semibold whitespace-nowrap">CO₂ (Nonpolar)</span>
                 <span className="px-3 py-1 bg-teal-100 text-teal-800 rounded-full text-xs font-semibold whitespace-nowrap">NH₃ (Polar)</span>
                 <span className="px-3 py-1 bg-slate-200 text-slate-700 rounded-full text-xs font-semibold whitespace-nowrap">CCl₄ (Nonpolar)</span>
              </div>
           </div>
        </Section>

        {/* --- SIMULATION SECTION --- */}
        <SimulationSection />

        {/* --- GAME SECTION --- */}
        <EducationalGame />

        {/* --- PRACTICE QUIZ SECTION --- */}
        <PracticeQuiz />

      </main>

      {/* Footer */}
      <footer className="text-center py-8 text-slate-400 text-sm">
        <p>© Materi Kimia SMA - Ikatan Kovalen</p>
      </footer>
    </div>
  );
}