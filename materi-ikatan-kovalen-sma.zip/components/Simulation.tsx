import React, { useState, useEffect } from 'react';
import { RefreshCw, Check, ArrowRight, Info, MousePointer2 } from 'lucide-react';

// --- MODULE 1: VALENCE ELECTRONS ---
const SimValence = () => {
  const atoms = [
    { symbol: 'H', number: 1, valence: 1, group: 'IA' },
    { symbol: 'C', number: 6, valence: 4, group: 'IV A' },
    { symbol: 'N', number: 7, valence: 5, group: 'V A' },
    { symbol: 'O', number: 8, valence: 6, group: 'VI A' },
    { symbol: 'F', number: 9, valence: 7, group: 'VII A' },
  ];
  const [selected, setSelected] = useState(atoms[0]);

  // Generate electron positions in a circle
  const getElectronPos = (index, total) => {
    const angle = (index / 8) * 2 * Math.PI - Math.PI / 2;
    const r = 60;
    return { x: 100 + r * Math.cos(angle), y: 100 + r * Math.sin(angle) };
  };

  return (
    <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
      <h3 className="text-lg font-bold text-slate-800 mb-4">1. Eksplorasi Elektron Valensi</h3>
      
      <div className="flex flex-wrap gap-2 mb-6">
        {atoms.map((atom) => (
          <button
            key={atom.symbol}
            onClick={() => setSelected(atom)}
            className={`w-10 h-10 rounded-full font-bold transition-colors ${
              selected.symbol === atom.symbol
                ? 'bg-teal-600 text-white'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            {atom.symbol}
          </button>
        ))}
      </div>

      <div className="flex flex-col md:flex-row items-center gap-8">
        <div className="relative w-52 h-52 bg-slate-50 rounded-full border border-slate-200 flex items-center justify-center">
          <div className="w-16 h-16 bg-slate-800 rounded-full flex items-center justify-center text-white text-2xl font-bold z-10">
            {selected.symbol}
          </div>
          {/* Valence Shell */}
          <div className="absolute w-40 h-40 rounded-full border-2 border-dashed border-slate-300"></div>
          
          {/* Electrons */}
          {Array.from({ length: selected.valence }).map((_, i) => {
            const pos = getElectronPos(i, selected.valence);
            return (
              <div
                key={i}
                className="absolute w-4 h-4 bg-yellow-400 rounded-full shadow-sm border border-yellow-600 transform -translate-x-1/2 -translate-y-1/2 transition-all duration-500"
                style={{ left: pos.x, top: pos.y }}
              ></div>
            );
          })}
        </div>

        <div className="flex-1 space-y-4">
          <div className="bg-teal-50 p-4 rounded-lg border-l-4 border-teal-500">
            <h4 className="font-bold text-teal-800">Observasi:</h4>
            <p className="text-sm text-teal-900 mt-1">
              Atom <strong>{selected.symbol}</strong> ada di Golongan <strong>{selected.group}</strong>.
              <br />
              Jumlah elektron valensi: <span className="text-xl font-bold ml-1">{selected.valence}</span>
            </p>
          </div>
          <p className="text-slate-600 italic text-sm">
            "Perhatikan pola jumlah elektron pada kulit terluar. Elektron inilah yang nanti akan dipakai berikatan."
          </p>
        </div>
      </div>
    </div>
  );
};

// --- MODULE 2: BOND FORMATION (Interactive) ---
const SimBonding = () => {
  const [molecule, setMolecule] = useState('H2');
  const [electrons, setElectrons] = useState([]); // Array of {id, location: 'left'|'right'|'shared', owner: 'left'|'right'}
  const [selectedElectron, setSelectedElectron] = useState(null);

  // Initialize scenario
  useEffect(() => {
    if (molecule === 'H2') {
      setElectrons([
        { id: 'l1', location: 'left', owner: 'left' },
        { id: 'r1', location: 'right', owner: 'right' }
      ]);
    } else if (molecule === 'O2') {
      // Simplification: Focus on the sharing electrons
      setElectrons([
        { id: 'l1', location: 'left', owner: 'left' },
        { id: 'l2', location: 'left', owner: 'left' },
        { id: 'r1', location: 'right', owner: 'right' },
        { id: 'r2', location: 'right', owner: 'right' }
      ]);
    } else if (molecule === 'H2O') {
      // O in center (treated as 'shared' zone owner initially?), H on sides.
      // Let's do a simplified visual for H2O: H(left) - O(center) - H(right)
      // We share into L-bond and R-bond.
      setElectrons([
        { id: 'hl', location: 'left', owner: 'left' }, // H left e
        { id: 'ol', location: 'center', owner: 'center' }, // O e for left bond
        { id: 'or', location: 'center', owner: 'center' }, // O e for right bond
        { id: 'hr', location: 'right', owner: 'right' }, // H right e
      ]);
    }
    setSelectedElectron(null);
  }, [molecule]);

  const moveElectron = (targetLoc) => {
    if (!selectedElectron) return;
    
    // Logic constraints
    const current = electrons.find(e => e.id === selectedElectron);
    
    // Allow move to shared if not there, or back to owner
    // For H2O: targetLoc can be 'bondLeft', 'bondRight'. 
    
    let newLoc = targetLoc;

    setElectrons(prev => prev.map(e => 
      e.id === selectedElectron ? { ...e, location: newLoc } : e
    ));
    setSelectedElectron(null);
  };

  const isShared = (loc) => loc === 'shared' || loc === 'bondLeft' || loc === 'bondRight';

  // H2/O2 Renderer
  const renderDiatomic = () => {
    const sharedCount = electrons.filter(e => e.location === 'shared').length;
    const isComplete = molecule === 'H2' ? sharedCount === 2 : sharedCount === 4;

    return (
      <div className="relative h-60 bg-slate-50 rounded-lg border border-slate-200 mt-4 overflow-hidden select-none">
        {/* Bonding Zone */}
        <div 
          onClick={() => moveElectron('shared')}
          className={`absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 w-32 h-32 rounded-full border-2 border-dashed flex items-center justify-center transition-colors cursor-pointer z-10 ${
            isComplete ? 'bg-green-100 border-green-500' : 'bg-transparent border-slate-300 hover:bg-slate-100'
          }`}
        >
           {isComplete && <span className="text-green-700 font-bold text-xs absolute -top-6">Ikatan Terbentuk!</span>}
        </div>

        {/* Atoms */}
        <div className="absolute left-10 top-1/2 transform -translate-y-1/2 w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center text-xl font-bold text-blue-800">
           {molecule === 'H2' ? 'H' : 'O'}
        </div>
        <div className="absolute right-10 top-1/2 transform -translate-y-1/2 w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center text-xl font-bold text-blue-800">
           {molecule === 'H2' ? 'H' : 'O'}
        </div>

        {/* Electrons */}
        {electrons.map((e, i) => {
            // Determine visual position
            let top = '50%';
            let left = '0%';
            
            if (e.location === 'left') {
                left = '20%';
                top = `${40 + i*10}%`; // stack slightly
            } else if (e.location === 'right') {
                left = '80%';
                top = `${40 + i*10}%`;
            } else if (e.location === 'shared') {
                left = '50%';
                top = `${45 + (i%2)*10}%`;
                // spread a bit
                if (molecule === 'O2') {
                   left = `${45 + (i*5)}%`;
                }
            }

            return (
                <button
                    key={e.id}
                    onClick={(evt) => {
                        evt.stopPropagation();
                        // If already shared, clicking moves back to owner
                        if(e.location === 'shared') {
                            moveElectron(e.owner);
                        } else {
                            setSelectedElectron(e.id);
                        }
                    }}
                    className={`absolute w-6 h-6 rounded-full border-2 transition-all duration-300 z-20 flex items-center justify-center font-bold text-[10px] ${
                        selectedElectron === e.id 
                            ? 'bg-yellow-300 border-yellow-600 scale-125 shadow-lg ring-2 ring-yellow-200' 
                            : e.location === 'shared' ? 'bg-green-400 border-green-700' : 'bg-yellow-400 border-yellow-600'
                    }`}
                    style={{ left, top, transform: 'translate(-50%, -50%)' }}
                >
                    e⁻
                </button>
            )
        })}
        
        {/* Instruction Overlay */}
        {!isComplete && (
            <div className="absolute bottom-2 w-full text-center text-xs text-slate-500">
                Klik elektron, lalu klik area tengah (putus-putus)
            </div>
        )}
      </div>
    );
  };

  return (
    <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
      <h3 className="text-lg font-bold text-slate-800 mb-4">2. Pembentukan Ikatan</h3>
      <div className="flex gap-2 mb-4">
        {['H2', 'O2'].map(m => (
          <button key={m} onClick={() => setMolecule(m)} className={`px-4 py-2 rounded-lg text-sm font-bold ${molecule === m ? 'bg-teal-600 text-white' : 'bg-slate-100'}`}>
            {m === 'H2' ? 'H₂' : 'O₂'}
          </button>
        ))}
        {/* H2O simplified to text or different viz if needed, keeping simple for now */}
      </div>

      <p className="text-sm text-slate-600 mb-2">
        Pindahkan elektron tak berpasangan ke area tengah untuk membentuk pasangan ikatan.
      </p>
      
      {renderDiatomic()}
    </div>
  );
};

// --- MODULE 3: LEWIS STRUCTURE ---
const SimLewis = () => {
    const [target, setTarget] = useState('H2O');
    // slots: key -> state (0: empty, 1: single, 2: pair)
    const [slots, setSlots] = useState({});
    const [feedback, setFeedback] = useState('');

    const configs = {
        H2O: {
            center: 'O',
            sides: [{pos:'left', atom:'H'}, {pos:'right', atom:'H'}],
            valenceNeeded: 8, // Total valence e- in system
            correct: { center_top: 2, center_bottom: 2, bond_left: 2, bond_right: 2 } // H-O-H
        },
        NH3: {
            center: 'N',
            sides: [{pos:'left', atom:'H'}, {pos:'right', atom:'H'}, {pos:'bottom', atom:'H'}],
            valenceNeeded: 8,
            correct: { center_top: 2, bond_left: 2, bond_right: 2, bond_bottom: 2 }
        },
        CO2: {
            center: 'C',
            sides: [{pos:'left', atom:'O'}, {pos:'right', atom:'O'}],
            valenceNeeded: 16,
            // O=C=O. O needs 2 pairs lone. C needs 4 bonds.
            // Simplified slot model: bond_left (4e), bond_right (4e), outer_left (4e), outer_right (4e)
            // This grid model is hard for CO2 double bonds.
            // Let's stick to H2O and NH3 for simplicity of the grid.
            // Replacing CO2 with CH4? Or just H2O/NH3.
            // Prompt asked for H2O, NH3, CO2.
            // I will implement a simplified check for CO2: just bonds.
        }
    };

    // Reset slots when target changes
    useEffect(() => {
        setSlots({});
        setFeedback('');
    }, [target]);

    const toggleSlot = (id) => {
        setSlots(prev => {
            const current = prev[id] || 0;
            const next = (current + 1) > 2 ? 0 : current + 1;
            return { ...prev, [id]: next };
        });
    };

    const checkAnswer = () => {
        const config = configs[target];
        if(!config) return;
        
        let correct = true;
        let totalE = 0;
        
        // Simple heuristic check
        // Check bonds
        if(target === 'H2O') {
             if(slots['bond_left'] !== 2 || slots['bond_right'] !== 2) correct = false;
             if(slots['center_top'] !== 2 || slots['center_bottom'] !== 2) correct = false;
        } else if(target === 'NH3') {
             if(slots['bond_left'] !== 2 || slots['bond_right'] !== 2 || slots['bond_bottom'] !== 2) correct = false;
             if(slots['center_top'] !== 2) correct = false;
        } else if(target === 'CO2') {
             // Hard to represent double bond in this UI, skipping CO2 complex logic
             // Or just make it H2O/NH3/CH4
             setFeedback('Simulasi ini fokus pada ikatan tunggal dulu ya!');
             return;
        }

        if(correct) {
            setFeedback('Benar! Struktur Lewis stabil (Oktet/Duplet terpenuhi).');
        } else {
            setFeedback('Belum tepat. Pastikan elektron valensi cukup dan aturan oktet terpenuhi.');
        }
    };

    // Render Helper
    const Slot = ({ id, style }) => {
        const val = slots[id] || 0;
        return (
            <button
                onClick={() => toggleSlot(id)}
                className={`absolute w-8 h-8 rounded border flex items-center justify-center transition-colors ${
                    val === 0 ? 'border-dashed border-slate-300 bg-transparent hover:bg-slate-50' : 'border-slate-800 bg-white'
                }`}
                style={style}
            >
                {val === 1 && <div className="w-2 h-2 bg-slate-800 rounded-full"></div>}
                {val === 2 && <div className="flex gap-1"><div className="w-2 h-2 bg-slate-800 rounded-full"></div><div className="w-2 h-2 bg-slate-800 rounded-full"></div></div>}
            </button>
        );
    };

    return (
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
            <h3 className="text-lg font-bold text-slate-800 mb-4">3. Latihan Struktur Lewis</h3>
            
            <div className="flex gap-2 mb-6">
                <button onClick={() => setTarget('H2O')} className={`px-3 py-1 rounded border ${target==='H2O'?'bg-teal-600 text-white':''}`}>H₂O</button>
                <button onClick={() => setTarget('NH3')} className={`px-3 py-1 rounded border ${target==='NH3'?'bg-teal-600 text-white':''}`}>NH₃</button>
            </div>

            <div className="relative h-64 bg-slate-50 border rounded-lg flex items-center justify-center">
                {/* Center Atom */}
                <div className="w-12 h-12 bg-white border border-slate-300 rounded flex items-center justify-center font-bold text-xl z-10">
                    {configs[target].center}
                </div>

                {/* Slots for Center */}
                <Slot id="center_top" style={{ top: 'calc(50% - 50px)', left: 'calc(50% - 16px)' }} />
                {(target === 'H2O') && <Slot id="center_bottom" style={{ top: 'calc(50% + 20px)', left: 'calc(50% - 16px)' }} />}

                {/* Bonds and Side Atoms */}
                {configs[target].sides.map((side, i) => {
                    let posStyle = {};
                    let bondSlotStyle = {};
                    if(side.pos === 'left') {
                        posStyle = { left: '20%', top: '50%' };
                        bondSlotStyle = { left: '35%', top: 'calc(50% - 16px)' };
                    } else if (side.pos === 'right') {
                        posStyle = { right: '20%', top: '50%' };
                        bondSlotStyle = { right: '35%', top: 'calc(50% - 16px)' };
                    } else if (side.pos === 'bottom') {
                        posStyle = { left: '50%', bottom: '15%' };
                        bondSlotStyle = { left: 'calc(50% - 16px)', bottom: '30%' };
                    }

                    return (
                        <React.Fragment key={i}>
                            <div className="absolute w-10 h-10 bg-blue-50 border border-blue-200 rounded-full flex items-center justify-center font-bold text-blue-800 transform -translate-y-1/2 -translate-x-1/2" style={posStyle}>
                                {side.atom}
                            </div>
                            <Slot id={`bond_${side.pos}`} style={bondSlotStyle} />
                        </React.Fragment>
                    )
                })}
            </div>

            <div className="mt-4 flex justify-between items-center">
                <p className="text-xs text-slate-500">Klik kotak putus-putus untuk menambah elektron.</p>
                <button onClick={checkAnswer} className="bg-teal-600 text-white px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2">
                    <Check size={16} /> Cek
                </button>
            </div>
            {feedback && (
                <div className={`mt-3 p-3 rounded text-sm ${feedback.includes('Benar') ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                    {feedback}
                </div>
            )}
        </div>
    );
};

// --- MODULE 4: POLARITY ---
const SimPolarity = () => {
    const [mol, setMol] = useState('H2O');
    const [showDipole, setShowDipole] = useState(false);
    const [showCharge, setShowCharge] = useState(false);

    return (
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
            <h3 className="text-lg font-bold text-slate-800 mb-4">4. Visualisasi Kepolaran</h3>
            
            <div className="flex justify-between items-start mb-6">
                <div className="flex gap-2">
                    <button onClick={() => setMol('H2O')} className={`px-3 py-1 rounded text-sm font-bold ${mol==='H2O'?'bg-teal-600 text-white':'bg-slate-100'}`}>H₂O</button>
                    <button onClick={() => setMol('CO2')} className={`px-3 py-1 rounded text-sm font-bold ${mol==='CO2'?'bg-teal-600 text-white':'bg-slate-100'}`}>CO₂</button>
                </div>
                <div className="flex flex-col gap-2">
                    <label className="flex items-center gap-2 text-sm cursor-pointer">
                        <input type="checkbox" checked={showCharge} onChange={(e) => setShowCharge(e.target.checked)} className="rounded text-teal-600" />
                        Muatan Parsial (δ)
                    </label>
                    <label className="flex items-center gap-2 text-sm cursor-pointer">
                        <input type="checkbox" checked={showDipole} onChange={(e) => setShowDipole(e.target.checked)} className="rounded text-teal-600" />
                        Momen Dipol (Panah)
                    </label>
                </div>
            </div>

            <div className="h-64 bg-slate-50 rounded-lg flex items-center justify-center relative border border-slate-200 overflow-hidden">
                 {mol === 'H2O' ? (
                     <div className="relative">
                         {/* Water Molecule */}
                         <div className="relative w-32 h-24">
                             {/* O */}
                             <div className="absolute left-1/2 top-0 transform -translate-x-1/2 w-16 h-16 bg-red-200 rounded-full flex items-center justify-center font-bold text-red-800 border-2 border-red-300">O</div>
                             {/* H left */}
                             <div className="absolute left-0 bottom-0 w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center font-bold text-blue-800 border-2 border-blue-200">H</div>
                             {/* H right */}
                             <div className="absolute right-0 bottom-0 w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center font-bold text-blue-800 border-2 border-blue-200">H</div>
                             
                             {/* Bonds */}
                             <div className="absolute left-8 bottom-8 w-1 h-10 bg-slate-300 transform -rotate-45 -z-10 origin-bottom"></div>
                             <div className="absolute right-8 bottom-8 w-1 h-10 bg-slate-300 transform rotate-45 -z-10 origin-bottom"></div>

                             {/* Partial Charges */}
                             {showCharge && (
                                 <>
                                     <div className="absolute -top-2 left-1/2 text-red-600 font-bold text-xs">δ-</div>
                                     <div className="absolute -bottom-2 -left-2 text-blue-600 font-bold text-xs">δ+</div>
                                     <div className="absolute -bottom-2 -right-2 text-blue-600 font-bold text-xs">δ+</div>
                                 </>
                             )}

                             {/* Dipoles */}
                             {showDipole && (
                                 <>
                                     {/* Individual */}
                                     <div className="absolute left-2 bottom-8 w-12 h-1 bg-yellow-400 transform -rotate-45 opacity-50"><div className="absolute right-0 -top-1 border-4 border-transparent border-l-yellow-400"></div></div>
                                     <div className="absolute right-2 bottom-8 w-12 h-1 bg-yellow-400 transform rotate-45 opacity-50"><div className="absolute right-0 -top-1 border-4 border-transparent border-l-yellow-400"></div></div>
                                     {/* Net */}
                                     <div className="absolute left-1/2 top-8 w-1 h-16 bg-teal-500 transform -translate-x-1/2 -translate-y-full flex flex-col items-center">
                                         <div className="w-0 h-0 border-l-[6px] border-r-[6px] border-b-[10px] border-transparent border-b-teal-500 absolute -top-2"></div>
                                         <span className="text-[10px] font-bold text-teal-700 whitespace-nowrap absolute -top-6 bg-white px-1 rounded">Resultan ≠ 0 (Polar)</span>
                                     </div>
                                 </>
                             )}
                         </div>
                     </div>
                 ) : (
                     <div className="relative">
                         {/* CO2 Molecule */}
                         <div className="flex items-center gap-1">
                             <div className="w-14 h-14 bg-red-200 rounded-full flex items-center justify-center font-bold text-red-800 border-2 border-red-300">O</div>
                             <div className="w-24 h-4 bg-slate-300 flex items-center justify-center relative">
                                <div className="w-14 h-14 bg-slate-200 rounded-full flex items-center justify-center font-bold text-slate-800 border-2 border-slate-300 absolute">C</div>
                             </div>
                             <div className="w-14 h-14 bg-red-200 rounded-full flex items-center justify-center font-bold text-red-800 border-2 border-red-300">O</div>
                         </div>

                         {showCharge && (
                             <>
                                 <div className="absolute left-2 -top-4 text-red-600 font-bold text-xs">δ-</div>
                                 <div className="absolute left-1/2 -top-8 text-blue-600 font-bold text-xs transform -translate-x-1/2">δ+</div>
                                 <div className="absolute right-2 -top-4 text-red-600 font-bold text-xs">δ-</div>
                             </>
                         )}

                         {showDipole && (
                             <>
                                 {/* Opposing dipoles */}
                                 <div className="absolute left-0 top-16 w-16 h-1 bg-yellow-400"><div className="absolute left-0 -top-1 border-4 border-transparent border-r-yellow-400"></div></div>
                                 <div className="absolute right-0 top-16 w-16 h-1 bg-yellow-400"><div className="absolute right-0 -top-1 border-4 border-transparent border-l-yellow-400"></div></div>
                                 <div className="absolute top-20 left-1/2 transform -translate-x-1/2 text-xs font-bold text-slate-500 bg-white px-2 py-1 rounded shadow-sm">
                                     Saling Meniadakan (Resultan = 0)
                                 </div>
                             </>
                         )}
                     </div>
                 )}
            </div>
            
            <div className="mt-4 bg-blue-50 p-3 rounded text-sm text-blue-800">
                <span className="font-bold">Refleksi:</span> {mol === 'H2O' ? 'Bentuk bengkok menyebabkan tarikan elektron tidak saling meniadakan, sehingga H₂O polar.' : 'Bentuk linear menyebabkan tarikan elektron saling meniadakan, sehingga CO₂ nonpolar.'}
            </div>
        </div>
    );
};

// --- MAIN SIMULATION CONTAINER ---
export const SimulationSection = () => {
  const [activeTab, setActiveTab] = useState(1);

  return (
    <section className="my-12 scroll-mt-20" id="simulasi">
      <div className="bg-teal-900 text-white p-6 rounded-t-2xl">
         <h2 className="text-2xl font-bold flex items-center gap-3">
            <RefreshCw className="animate-spin-slow" />
            Simulasi Ikatan Kovalen
         </h2>
         <p className="text-teal-200 mt-2">Eksplorasi interaktif untuk memahami pembentukan ikatan.</p>
      </div>
      
      <div className="bg-slate-800 p-2 overflow-x-auto">
        <div className="flex space-x-2 min-w-max">
            {[
                {id: 1, label: '1. Elektron Valensi'},
                {id: 2, label: '2. Pembentukan Ikatan'},
                {id: 3, label: '3. Struktur Lewis'},
                {id: 4, label: '4. Kepolaran'}
            ].map(tab => (
                <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                        activeTab === tab.id 
                        ? 'bg-teal-500 text-white shadow-lg' 
                        : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                    }`}
                >
                    {tab.label}
                </button>
            ))}
        </div>
      </div>

      <div className="bg-slate-100 p-4 md:p-6 rounded-b-2xl min-h-[400px]">
         {activeTab === 1 && <SimValence />}
         {activeTab === 2 && <SimBonding />}
         {activeTab === 3 && <SimLewis />}
         {activeTab === 4 && <SimPolarity />}
      </div>
    </section>
  );
};