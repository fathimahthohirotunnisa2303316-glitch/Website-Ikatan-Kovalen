import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

interface SectionProps {
  title: string;
  children: React.ReactNode;
  defaultOpen?: boolean;
  number: string;
}

export const Section: React.FC<SectionProps> = ({ title, children, defaultOpen = false, number }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="mb-6 bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden transition-all duration-300">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`w-full flex items-center justify-between p-5 text-left transition-colors ${
          isOpen ? 'bg-teal-50 text-teal-900' : 'bg-white text-slate-700 hover:bg-slate-50'
        }`}
      >
        <div className="flex items-center gap-3">
          <span className="flex items-center justify-center w-8 h-8 rounded-full bg-teal-100 text-teal-700 font-bold text-sm">
            {number}
          </span>
          <h2 className="text-lg font-bold">{title}</h2>
        </div>
        {isOpen ? <ChevronUp className="w-5 h-5 text-teal-600" /> : <ChevronDown className="w-5 h-5 text-slate-400" />}
      </button>
      
      {isOpen && (
        <div className="p-5 border-t border-slate-100 animate-fadeIn">
          {children}
        </div>
      )}
    </div>
  );
};