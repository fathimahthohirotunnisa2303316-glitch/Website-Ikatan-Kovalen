import React, { useState } from 'react';
import { CheckCircle2, XCircle, HelpCircle, Trophy, ChevronRight, BarChart3 } from 'lucide-react';

// --- DATA SOAL ---

const questions = {
  basic: [
    {
      id: 'b1',
      question: "Apa perbedaan mendasar antara ikatan kovalen dan ikatan ion?",
      options: [
        "Ikatan kovalen terjadi serah terima elektron, ikatan ion penggunaan bersama elektron.",
        "Ikatan kovalen terjadi antara logam dan non-logam.",
        "Ikatan kovalen terjadi akibat penggunaan bersama pasangan elektron, ikatan ion akibat serah terima elektron.",
        "Ikatan kovalen selalu menghasilkan larutan yang menghantarkan listrik."
      ],
      correct: 2,
      explanation: "Ikatan Kovalen terbentuk karena penggunaan bersama (sharing) elektron antar atom non-logam. Ikatan Ion terbentuk karena serah terima elektron (transfer) antara logam dan non-logam."
    },
    {
      id: 'b2',
      question: "Atom Karbon (nomor atom 6) memiliki konfigurasi elektron 2.4. Berapa elektron lagi yang dibutuhkan Karbon untuk mencapai kestabilan oktet?",
      options: [
        "1 elektron",
        "2 elektron",
        "4 elektron",
        "Melepas 4 elektron"
      ],
      correct: 2,
      explanation: "Karbon memiliki 4 elektron valensi. Untuk mencapai oktet (8 elektron), ia membutuhkan 4 elektron tambahan melalui pembentukan ikatan kovalen."
    }
  ],
  lewis: [
    {
      id: 'l1',
      question: "Berapa total elektron valensi yang harus digambar dalam struktur Lewis molekul CO₂? (C=Gol.4, O=Gol.6)",
      options: [
        "10 elektron",
        "12 elektron",
        "16 elektron",
        "18 elektron"
      ],
      correct: 2,
      explanation: "C (4 valensi) + 2 atom O (2 × 6 valensi) = 4 + 12 = 16 elektron valensi."
    },
    {
      id: 'l2',
      question: "Pada molekul Amonia (NH₃), atom Nitrogen memiliki 5 elektron valensi dan berikatan dengan 3 atom Hidrogen. Berapa jumlah Pasangan Elektron Bebas (PEB) pada atom Nitrogen?",
      options: [
        "0 pasang",
        "1 pasang",
        "2 pasang",
        "3 pasang"
      ],
      correct: 1,
      explanation: "Nitrogen punya 5 e- valensi. Dipakai 3 untuk berikatan dengan H. Sisa = 5 - 3 = 2 elektron (1 pasang elektron bebas)."
    }
  ],
  polarity: [
    {
      id: 'p1',
      question: "Molekul manakah di bawah ini yang bersifat POLAR?",
      options: [
        "CH₄ (Metana)",
        "H₂ (Hidrogen)",
        "HCl (Asam Klorida)",
        "CO₂ (Karbon Dioksida)"
      ],
      correct: 2,
      explanation: "HCl polar karena ada perbedaan keelektronegatifan tinggi antara H dan Cl, dan bentuknya asimetris (linear tapi dua atom beda)."
    },
    {
      id: 'p2',
      question: "Mengapa molekul CCl₄ bersifat NONPOLAR padahal ikatan C-Cl bersifat polar?",
      options: [
        "Karena C dan Cl memiliki keelektronegatifan sama.",
        "Karena bentuk molekulnya simetris (tetrahedral) sehingga momen dipol saling meniadakan.",
        "Karena tidak ada elektron bebas.",
        "Karena ikatan yang terjadi adalah ikatan ion."
      ],
      correct: 1,
      explanation: "Meskipun ikatan C-Cl polar, bentuk CCl₄ yang simetris sempurna (tetrahedral) menyebabkan tarikan vektor muatan saling meniadakan (Resultan = 0)."
    }
  ],
  diagnostic: [
    {
      id: 'd1',
      question: "Apakah senyawa BF₃ (Boron Trifluorida) memenuhi aturan oktet pada atom pusat B? (B=Gol.3, F=Gol.7)",
      tier1: [
        "Ya, memenuhi oktet.",
        "Tidak, tidak memenuhi oktet."
      ],
      correctTier1: 1,
      tier2Question: "Alasannya adalah:",
      tier2: [
        "Atom B dikelilingi 8 elektron hasil sharing.",
        "Atom B hanya memiliki 3 elektron valensi, sehingga total hanya dikelilingi 6 elektron setelah berikatan.",
        "Atom F memberikan elektronnya kepada B.",
        "Atom B kelebihan elektron (lebih dari 8)."
      ],
      correctTier2: 1,
      explanation: "Penyimpangan Oktet: Boron (Gol IIIA) hanya punya 3 elektron valensi. Saat berikatan dengan 3 F, total elektron di sekitar B hanya 6 (bukan 8)."
    },
    {
      id: 'd2',
      question: "Molekul Air (H₂O) bersifat polar. Benar atau Salah?",
      tier1: [
        "Benar (Polar)",
        "Salah (Nonpolar)"
      ],
      correctTier1: 0,
      tier2Question: "Alasannya adalah:",
      tier2: [
        "Karena atom H dan O memiliki keelektronegatifan sama.",
        "Karena bentuk molekulnya linear sehingga muatan tersebar merata.",
        "Karena terdapat pasangan elektron bebas pada O yang membuat bentuk bengkok dan distribusi muatan tidak simetris.",
        "Karena H₂O adalah senyawa ionik."
      ],
      correctTier2: 2,
      explanation: "H₂O polar karena bentuknya V (bengkok) akibat tolakan 2 pasang elektron bebas. Hal ini membuat resultan momen dipol tidak nol."
    },
    {
      id: 'd3',
      question: "Apakah suatu molekul yang mengandung ikatan rangkap pasti bersifat polar?",
      tier1: [
        "Ya, pasti polar.",
        "Tidak, belum tentu polar."
      ],
      correctTier1: 1,
      tier2Question: "Alasannya adalah:",
      tier2: [
        "Ikatan rangkap selalu menarik elektron lebih kuat.",
        "Kepolaran molekul ditentukan oleh simetri bentuk molekul, bukan hanya jenis ikatan.",
        "Ikatan rangkap tidak memiliki muatan.",
        "Hanya ikatan tunggal yang bisa membentuk molekul nonpolar."
      ],
      correctTier2: 1,
      explanation: "Contoh CO₂ (O=C=O) punya ikatan rangkap tapi Nonpolar karena bentuknya linear simetris."
    }
  ]
};

// --- COMPONENT ---

export const PracticeQuiz = () => {
  const [activeTab, setActiveTab] = useState<'basic' | 'lewis' | 'polarity' | 'diagnostic'>('basic');
  const [answers, setAnswers] = useState<Record<string, number>>({}); 
  const [answersTier2, setAnswersTier2] = useState<Record<string, number>>({}); // For diagnostic tier 2
  const [feedbackState, setFeedbackState] = useState<Record<string, boolean>>({}); // Show feedback?

  const tabs = [
    { id: 'basic', label: '1. Konsep Dasar' },
    { id: 'lewis', label: '2. Struktur Lewis' },
    { id: 'polarity', label: '3. Kepolaran' },
    { id: 'diagnostic', label: '4. Diagnostik (Two-Tier)' },
  ];

  const handleSelect = (qId: string, optionIdx: number, tier: 1 | 2 = 1) => {
    if (feedbackState[qId]) return; // Prevent changing after checking

    if (tier === 1) {
      setAnswers(prev => ({ ...prev, [qId]: optionIdx }));
    } else {
      setAnswersTier2(prev => ({ ...prev, [qId]: optionIdx }));
    }
  };

  const checkAnswer = (qId: string) => {
    setFeedbackState(prev => ({ ...prev, [qId]: true }));
  };

  // Helper to count progress
  const totalQuestions = 
    questions.basic.length + questions.lewis.length + questions.polarity.length + questions.diagnostic.length;
  const answeredCount = Object.keys(feedbackState).length;
  const progress = Math.round((answeredCount / totalQuestions) * 100);

  const renderStandardQuestion = (q: any, index: number) => {
    const isAnswered = feedbackState[q.id];
    const selected = answers[q.id];
    const isCorrect = selected === q.correct;

    return (
      <div key={q.id} className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm mb-6">
        <div className="flex justify-between items-start mb-4">
            <span className="bg-teal-100 text-teal-800 text-xs font-bold px-2 py-1 rounded">Soal {index + 1}</span>
            {isAnswered && (
                isCorrect 
                ? <span className="flex items-center text-green-600 font-bold text-sm"><CheckCircle2 className="w-4 h-4 mr-1"/> Benar</span>
                : <span className="flex items-center text-red-500 font-bold text-sm"><XCircle className="w-4 h-4 mr-1"/> Salah</span>
            )}
        </div>
        
        <p className="text-slate-800 font-medium mb-4 text-lg">{q.question}</p>

        <div className="space-y-3">
          {q.options.map((opt: string, idx: number) => (
            <button
              key={idx}
              onClick={() => handleSelect(q.id, idx)}
              disabled={isAnswered}
              className={`w-full text-left p-3 rounded-lg border transition-all ${
                isAnswered
                  ? idx === q.correct 
                    ? 'bg-green-50 border-green-500 text-green-800 font-medium' // Show correct
                    : idx === selected 
                        ? 'bg-red-50 border-red-500 text-red-800' // Show user error
                        : 'bg-slate-50 border-slate-200 text-slate-400' // Dim others
                  : selected === idx
                    ? 'bg-teal-50 border-teal-500 text-teal-900 shadow-sm'
                    : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-700'
              }`}
            >
              <div className="flex gap-3">
                 <div className={`w-6 h-6 rounded-full border flex items-center justify-center flex-shrink-0 ${
                     isAnswered && idx === q.correct ? 'bg-green-500 border-green-500 text-white' : 
                     isAnswered && idx === selected ? 'bg-red-500 border-red-500 text-white' :
                     selected === idx ? 'bg-teal-500 border-teal-500 text-white' : 'border-slate-300'
                 }`}>
                    {String.fromCharCode(65 + idx)}
                 </div>
                 <span>{opt}</span>
              </div>
            </button>
          ))}
        </div>

        {!isAnswered ? (
            <button 
                onClick={() => checkAnswer(q.id)}
                disabled={selected === undefined}
                className={`mt-6 w-full py-2 rounded-lg font-bold transition-all ${
                    selected !== undefined 
                    ? 'bg-teal-600 text-white hover:bg-teal-700 shadow-md' 
                    : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                }`}
            >
                Cek Jawaban
            </button>
        ) : (
            <div className={`mt-4 p-4 rounded-lg border ${isCorrect ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
                <h4 className={`font-bold text-sm mb-1 ${isCorrect ? 'text-green-800' : 'text-red-800'}`}>Pembahasan:</h4>
                <p className="text-slate-700 text-sm">{q.explanation}</p>
            </div>
        )}
      </div>
    );
  };

  const renderDiagnosticQuestion = (q: any, index: number) => {
    const isAnswered = feedbackState[q.id];
    const selT1 = answers[q.id];
    const selT2 = answersTier2[q.id];
    
    // Correct only if BOTH tiers are correct
    const isCorrect = selT1 === q.correctTier1 && selT2 === q.correctTier2;
    // Partially correct logic could be added, but strict grading is better for diagnostics

    return (
      <div key={q.id} className="bg-white p-6 rounded-xl border-l-4 border-l-purple-500 shadow-sm mb-6">
        <div className="flex justify-between items-start mb-4">
            <span className="bg-purple-100 text-purple-800 text-xs font-bold px-2 py-1 rounded flex items-center gap-1">
                <HelpCircle className="w-3 h-3"/> Diagnostik {index + 1}
            </span>
            {isAnswered && (
                isCorrect 
                ? <span className="flex items-center text-green-600 font-bold text-sm"><CheckCircle2 className="w-4 h-4 mr-1"/> Paham Utuh</span>
                : <span className="flex items-center text-orange-500 font-bold text-sm"><XCircle className="w-4 h-4 mr-1"/> Miskonsepsi/Salah</span>
            )}
        </div>

        {/* Tier 1 */}
        <div className="mb-6">
            <p className="font-semibold text-slate-800 mb-3">{q.question}</p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {q.tier1.map((opt: string, idx: number) => (
                    <button
                        key={idx}
                        onClick={() => handleSelect(q.id, idx, 1)}
                        disabled={isAnswered}
                        className={`p-3 rounded-lg border text-sm text-left ${
                            isAnswered 
                            ? idx === q.correctTier1 ? 'bg-green-50 border-green-400 font-medium' : idx === selT1 ? 'bg-red-50 border-red-400' : 'opacity-60'
                            : selT1 === idx ? 'bg-purple-50 border-purple-500 text-purple-900' : 'hover:bg-slate-50'
                        }`}
                    >
                        {opt}
                    </button>
                ))}
            </div>
        </div>

        {/* Tier 2 */}
        <div className="mb-6 border-t pt-4">
            <p className="font-semibold text-slate-800 mb-3 text-sm text-slate-500">{q.tier2Question}</p>
            <div className="space-y-2">
                {q.tier2.map((opt: string, idx: number) => (
                    <button
                        key={idx}
                        onClick={() => handleSelect(q.id, idx, 2)}
                        disabled={isAnswered}
                        className={`w-full p-3 rounded-lg border text-sm text-left ${
                             isAnswered 
                            ? idx === q.correctTier2 ? 'bg-green-50 border-green-400 font-medium' : idx === selT2 ? 'bg-red-50 border-red-400' : 'opacity-60'
                            : selT2 === idx ? 'bg-purple-50 border-purple-500 text-purple-900' : 'hover:bg-slate-50'
                        }`}
                    >
                        {opt}
                    </button>
                ))}
            </div>
        </div>

        {/* Check Button */}
        {!isAnswered ? (
            <button 
                onClick={() => checkAnswer(q.id)}
                disabled={selT1 === undefined || selT2 === undefined}
                className={`w-full py-2 rounded-lg font-bold transition-all ${
                    selT1 !== undefined && selT2 !== undefined
                    ? 'bg-purple-600 text-white hover:bg-purple-700 shadow-md' 
                    : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                }`}
            >
                Cek Pemahaman
            </button>
        ) : (
            <div className="bg-slate-800 text-white p-4 rounded-lg text-sm">
                <span className="font-bold text-yellow-400">Analisis Konsep:</span> {q.explanation}
            </div>
        )}

      </div>
    );
  };

  return (
    <section className="my-12 scroll-mt-20" id="latihan">
        {/* Header */}
        <div className="bg-gradient-to-r from-teal-800 to-slate-800 text-white p-8 rounded-t-2xl">
            <div className="flex items-center justify-between">
                <div>
                    <h2 className="text-2xl font-bold flex items-center gap-2">
                        <Trophy className="text-yellow-400" />
                        Latihan Soal
                    </h2>
                    <p className="text-slate-300 mt-2">Uji pemahamanmu tentang ikatan kovalen.</p>
                </div>
                <div className="text-right">
                    <div className="text-3xl font-bold text-teal-400">{progress}%</div>
                    <div className="text-xs text-slate-400">Selesai</div>
                </div>
            </div>
            {/* Progress Bar */}
            <div className="w-full bg-slate-700 h-2 rounded-full mt-4 overflow-hidden">
                <div className="bg-teal-400 h-full transition-all duration-500" style={{ width: `${progress}%` }}></div>
            </div>
        </div>

        {/* Tabs */}
        <div className="bg-white border-b border-slate-200 overflow-x-auto">
            <div className="flex min-w-max px-4">
                {tabs.map(tab => (
                    <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id as any)}
                        className={`px-6 py-4 text-sm font-medium border-b-2 transition-colors ${
                            activeTab === tab.id 
                            ? 'border-teal-600 text-teal-800' 
                            : 'border-transparent text-slate-500 hover:text-slate-700'
                        }`}
                    >
                        {tab.label}
                    </button>
                ))}
            </div>
        </div>

        {/* Content Area */}
        <div className="bg-slate-50 p-6 min-h-[400px] border border-t-0 border-slate-200 rounded-b-2xl">
            {activeTab === 'basic' && questions.basic.map((q, i) => renderStandardQuestion(q, i))}
            {activeTab === 'lewis' && questions.lewis.map((q, i) => renderStandardQuestion(q, i))}
            {activeTab === 'polarity' && questions.polarity.map((q, i) => renderStandardQuestion(q, i))}
            {activeTab === 'diagnostic' && (
                <div>
                    <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200 mb-6 flex gap-3 text-sm text-yellow-800">
                        <BarChart3 className="flex-shrink-0" />
                        <p>Soal tipe <strong>Two-Tier</strong> mengharuskan kamu memilih jawaban DAN alasannya. Jawaban hanya dianggap benar jika keduanya tepat.</p>
                    </div>
                    {questions.diagnostic.map((q, i) => renderDiagnosticQuestion(q, i))}
                </div>
            )}
            
            {/* Navigation Hint */}
            {answeredCount === totalQuestions && (
                <div className="text-center p-8 bg-green-100 rounded-xl border border-green-300">
                    <h3 className="text-xl font-bold text-green-800 mb-2">Selamat! 🎉</h3>
                    <p className="text-green-900">Kamu telah menyelesaikan semua latihan soal.</p>
                </div>
            )}
        </div>
    </section>
  );
};