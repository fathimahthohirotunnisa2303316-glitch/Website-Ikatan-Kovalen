import React from 'react';

// Common props for molecule SVGs
interface MolProps {
  className?: string;
}

export const MoleculeH2O: React.FC<MolProps> = ({ className }) => (
  <div className={`flex flex-col items-center ${className}`}>
    <div className="text-sm font-semibold mb-2 text-slate-500">Air (H₂O)</div>
    <svg width="150" height="120" viewBox="0 0 150 120" className="bg-white rounded-lg">
      {/* Oxygen */}
      <circle cx="75" cy="50" r="20" fill="#ffb3ba" stroke="#e17b85" strokeWidth="2" />
      <text x="75" y="55" textAnchor="middle" fontSize="16" fontWeight="bold" fill="#7f383e">O</text>
      
      {/* Hydrogens */}
      <circle cx="35" cy="90" r="12" fill="#bae1ff" stroke="#7bbbe1" strokeWidth="2" />
      <text x="35" y="94" textAnchor="middle" fontSize="12" fontWeight="bold" fill="#2d5f7f">H</text>
      
      <circle cx="115" cy="90" r="12" fill="#bae1ff" stroke="#7bbbe1" strokeWidth="2" />
      <text x="115" y="94" textAnchor="middle" fontSize="12" fontWeight="bold" fill="#2d5f7f">H</text>
      
      {/* Bonds */}
      <line x1="63" y1="64" x2="43" y2="82" stroke="#64748b" strokeWidth="3" />
      <line x1="87" y1="64" x2="107" y2="82" stroke="#64748b" strokeWidth="3" />
      
      {/* Lone Pairs on O */}
      <circle cx="60" cy="35" r="2" fill="#e17b85" />
      <circle cx="65" cy="30" r="2" fill="#e17b85" />
      <circle cx="90" cy="35" r="2" fill="#e17b85" />
      <circle cx="85" cy="30" r="2" fill="#e17b85" />
    </svg>
    <p className="text-xs text-slate-400 mt-1">Struktur Bengkok (V-shape)</p>
  </div>
);

export const LewisH2O: React.FC<MolProps> = ({ className }) => (
  <div className={`flex flex-col items-center p-3 bg-slate-50 rounded-lg border border-slate-200 ${className}`}>
    <div className="font-mono text-xl tracking-widest text-slate-800">
      <div className="flex items-center gap-1">
        <span>H</span>
        <span className="text-teal-600 font-bold mx-1">:</span>
        <div className="flex flex-col items-center relative">
          <span className="text-red-500 absolute -top-4 text-xs font-bold">..</span>
          <span>O</span>
          <span className="text-red-500 absolute -bottom-4 text-xs font-bold">..</span>
        </div>
        <span className="text-teal-600 font-bold mx-1">:</span>
        <span>H</span>
      </div>
    </div>
    <div className="text-xs text-slate-500 mt-4 text-center">
      <span className="text-teal-600 font-bold">:</span> Pasangan Ikatan (PEI)<br/>
      <span className="text-red-500 font-bold">..</span> Pasangan Bebas (PEB)
    </div>
  </div>
);

export const BondTypesVisual: React.FC = () => (
  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
    {/* Single Bond */}
    <div className="flex flex-col items-center p-4 bg-white border border-slate-200 rounded-lg">
      <h4 className="font-bold text-teal-700 mb-2">Tunggal</h4>
      <div className="text-2xl font-mono mb-2">H — H</div>
      <div className="text-xs text-slate-500 text-center">1 pasang elektron<br/>digunakan bersama</div>
    </div>
    {/* Double Bond */}
    <div className="flex flex-col items-center p-4 bg-white border border-slate-200 rounded-lg">
      <h4 className="font-bold text-teal-700 mb-2">Rangkap 2</h4>
      <div className="text-2xl font-mono mb-2">O = O</div>
      <div className="text-xs text-slate-500 text-center">2 pasang elektron<br/>digunakan bersama</div>
    </div>
    {/* Triple Bond */}
    <div className="flex flex-col items-center p-4 bg-white border border-slate-200 rounded-lg">
      <h4 className="font-bold text-teal-700 mb-2">Rangkap 3</h4>
      <div className="text-2xl font-mono mb-2">N ≡ N</div>
      <div className="text-xs text-slate-500 text-center">3 pasang elektron<br/>digunakan bersama</div>
    </div>
  </div>
);

export const PolarityVisual: React.FC = () => (
  <div className="flex flex-col md:flex-row gap-8 justify-center items-center my-4">
    {/* Non Polar */}
    <div className="flex flex-col items-center">
      <div className="relative w-32 h-16 bg-slate-100 rounded-full flex items-center justify-center border-2 border-slate-300">
        <div className="absolute left-2 w-10 h-10 rounded-full bg-blue-200 flex items-center justify-center font-bold text-slate-700">Cl</div>
        <div className="w-full border-t-2 border-slate-400 border-dashed"></div>
        <div className="absolute right-2 w-10 h-10 rounded-full bg-blue-200 flex items-center justify-center font-bold text-slate-700">Cl</div>
      </div>
      <p className="mt-2 font-semibold text-slate-700">Nonpolar</p>
      <p className="text-xs text-slate-500">Tarikan seimbang</p>
    </div>

    {/* Polar */}
    <div className="flex flex-col items-center">
      <div className="relative w-32 h-16 bg-slate-100 rounded-full flex items-center justify-center border-2 border-slate-300">
        <div className="absolute left-2 w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center font-bold text-xs text-slate-700">H</div>
        <div className="absolute left-6 top-1 text-teal-600 text-xs font-bold">δ+</div>
        
        <div className="w-full border-t-2 border-slate-400 border-dashed transform rotate-2"></div>
        
        <div className="absolute right-2 w-12 h-12 rounded-full bg-red-200 flex items-center justify-center font-bold text-slate-700">Cl</div>
        <div className="absolute right-10 top-1 text-red-600 text-xs font-bold">δ-</div>
      </div>
      <p className="mt-2 font-semibold text-slate-700">Polar</p>
      <p className="text-xs text-slate-500">Tarikan ke arah Cl</p>
    </div>
  </div>
);