import React, { useState } from 'react';

interface TooltipProps {
  term: string;
  definition: string;
}

export const Tooltip: React.FC<TooltipProps> = ({ term, definition }) => {
  const [isVisible, setIsVisible] = useState(false);

  return (
    <span 
      className="relative inline-block border-b-2 border-dashed border-teal-400 cursor-help font-medium text-teal-700 mx-1"
      onMouseEnter={() => setIsVisible(true)}
      onMouseLeave={() => setIsVisible(false)}
      onClick={() => setIsVisible(!isVisible)} // Mobile support
    >
      {term}
      {isVisible && (
        <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 w-64 p-3 bg-slate-800 text-white text-sm rounded-lg shadow-lg z-50 pointer-events-none">
          {definition}
          <div className="absolute top-full left-1/2 transform -translate-x-1/2 border-8 border-transparent border-t-slate-800"></div>
        </div>
      )}
    </span>
  );
};