import React, { useState, useEffect } from 'react';
import { Gamepad2, Star, Trophy, RotateCcw, Check, X, ArrowRight, Brain, Zap, HelpCircle } from 'lucide-react';

// --- GAME DATA ---

const GAME_1_DATA = [
  { id: 1, name: "Hidrogen", formula: "H₂", type: "Tunggal", explanation: "H hanya butuh 1 elektron tambahan untuk duplet." },
  { id: 2, name: "Oksigen", formula: "O₂", type: "Rangkap 2", explanation: "O butuh 2 elektron untuk oktet, jadi mereka berbagi 2 pasang." },
  { id: 3, name: "Nitrogen", formula: "N₂", type: "Rangkap 3", explanation: "N butuh 3 elektron, membentuk ikatan sangat kuat." },
  { id: 4, name: "Klorin", formula: "Cl₂", type: "Tunggal", explanation: "Cl Golongan 7A, hanya butuh 1 elektron." },
  { id: 5, name: "Karbon Dioksida", formula: "CO₂", type: "Rangkap 2", explanation: "Ikatan antara C dan O adalah rangkap dua." },
];

const GAME_3_DATA = [
  { id: 1, text: "Semua molekul dengan ikatan kovalen polar pasti bersifat polar.", isFact: false, explanation: "Mitos! Jika bentuknya simetris (seperti CO₂), muatannya saling meniadakan menjadi nonpolar." },
  { id: 2, text: "Ikatan kovalen terjadi antara sesama non-logam.", isFact: true, explanation: "Benar! Non-logam cenderung berbagi elektron." },
  { id: 3, text: "Air (H₂O) adalah molekul polar.", isFact: true, explanation: "Benar! Bentuknya bengkok dan ada perbedaan keelektronegatifan." },
  { id: 4, text: "Aturan oktet berlaku mutlak untuk semua atom.", isFact: false, explanation: "Mitos! Ada pengecualian seperti PCl₅ (lebih dari 8) atau BF₃ (kurang dari 8)." },
  { id: 5, text: "Ikatan rangkap tiga lebih pendek dan kuat dari ikatan tunggal.", isFact: true, explanation: "Benar! Tarikan antar inti lebih kuat." },
];

// --- SUB-COMPONENTS ---

const ScoreBoard = ({ score, streak }: { score: number, streak?: number }) => (
  <div className="flex items-center gap-4 bg-slate-800 text-white px-4 py-2 rounded-full shadow-lg border border-slate-600">
    <div className="flex items-center gap-2">
      <Trophy className="text-yellow-400 w-5 h-5" />
      <span className="font-bold text-lg">{score}</span>
    </div>
    {streak !== undefined && streak > 1 && (
      <div className="flex items-center gap-1 text-orange-400 text-sm font-bold border-l border-slate-600 pl-3">
        <Zap className="w-4 h-4 fill-orange-400" /> {streak}x Streak
      </div>
    )}
  </div>
);

// Game 1: Tebak Jenis Ikatan
const GameGuessBond = ({ onScore }: { onScore: (points: number) => void }) => {
  const [qIndex, setQIndex] = useState(0);
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; text: string } | null>(null);

  const currentQ = GAME_1_DATA[qIndex];

  const handleAnswer = (ans: string) => {
    if (feedback) return;
    const isCorrect = ans === currentQ.type;
    if (isCorrect) onScore(100);
    setFeedback({
      isCorrect,
      text: isCorrect ? "Tepat sekali! " + currentQ.explanation : "Kurang tepat. " + currentQ.explanation
    });
  };

  const nextQ = () => {
    setFeedback(null);
    setQIndex((prev) => (prev + 1) % GAME_1_DATA.length);
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[300px] text-center">
      <h3 className="text-xl font-bold text-slate-700 mb-6">Tebak Jenis Ikatan</h3>
      
      <div className="bg-white p-8 rounded-2xl shadow-md border-b-4 border-slate-200 mb-6 w-full max-w-sm">
        <div className="text-4xl font-black text-slate-800 mb-2">{currentQ.formula}</div>
        <div className="text-slate-500 font-medium">{currentQ.name}</div>
      </div>

      {!feedback ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 w-full max-w-md">
          {["Tunggal", "Rangkap 2", "Rangkap 3"].map((type) => (
            <button
              key={type}
              onClick={() => handleAnswer(type)}
              className="bg-indigo-100 hover:bg-indigo-200 text-indigo-800 py-3 rounded-xl font-bold transition-all transform hover:scale-105"
            >
              {type}
            </button>
          ))}
        </div>
      ) : (
        <div className={`w-full max-w-md p-4 rounded-xl ${feedback.isCorrect ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
          <div className="font-bold flex items-center justify-center gap-2 mb-2">
            {feedback.isCorrect ? <Check /> : <X />} 
            {feedback.isCorrect ? "Benar!" : "Salah!"}
          </div>
          <p className="text-sm mb-4">{feedback.text}</p>
          <button onClick={nextQ} className="bg-slate-800 text-white px-6 py-2 rounded-lg font-bold w-full">
            Lanjut <ArrowRight className="inline w-4 h-4 ml-1" />
          </button>
        </div>
      )}
    </div>
  );
};

// Game 2: Susun Lewis (Click-to-place simplified)
const GameLewisBuilder = ({ onScore }: { onScore: (points: number) => void }) => {
  const levels = [
    { name: "H₂O", center: "O", sides: ["H", "H"], correctPairs: [2, 2, 0, 0] }, // Top, Bottom, Left, Right
    { name: "NH₃", center: "N", sides: ["H", "H", "H"], correctPairs: [2, 0, 0, 0] } // Assuming standard orientation logic
  ];
  // Simplification for Game:
  // "Lengkapi PEB (Pasangan Elektron Bebas) pada atom pusat!"
  // User toggles dots on Top/Bottom/Left/Right of center atom.
  
  const [levelIdx, setLevelIdx] = useState(0);
  const [slots, setSlots] = useState([false, false, false, false]); // Top, Bottom, Left, Right
  const [submitted, setSubmitted] = useState(false);
  const [msg, setMsg] = useState("");

  const currentLevel = levels[levelIdx];

  const toggleSlot = (idx: number) => {
    if (submitted) return;
    setSlots(prev => {
      const n = [...prev];
      n[idx] = !n[idx];
      return n;
    });
  };

  const check = () => {
    // Logic: Determine correct pattern. 
    // H2O: Center O needs 2 lone pairs. Usually Top/Bottom or "Bunny ears". 
    // Let's accept any combination of N pairs where N is correct.
    const neededPairs = currentLevel.name === "H₂O" ? 2 : 1; 
    const userPairs = slots.filter(Boolean).length;

    if (userPairs === neededPairs) {
      setMsg("Hebat! Struktur Lewis stabil.");
      onScore(150);
      setSubmitted(true);
    } else {
      setMsg(`Kurang tepat. Atom pusat butuh ${neededPairs} Pasangan Elektron Bebas.`);
      setSubmitted(true); // Soft fail, let them retry by resetting manually or auto next
    }
  };

  const next = () => {
    setSlots([false, false, false, false]);
    setSubmitted(false);
    setMsg("");
    setLevelIdx(prev => (prev + 1) % levels.length);
  };

  return (
    <div className="flex flex-col items-center">
      <h3 className="text-xl font-bold text-slate-700 mb-2">Lengkapi Elektron Bebas</h3>
      <p className="text-slate-500 mb-6 text-center text-sm">Klik area sekitar atom pusat untuk menambah/menghapus PEB agar oktet tercapai.</p>
      
      <div className="relative w-64 h-64 bg-slate-50 rounded-full border-2 border-slate-200 mb-6 flex items-center justify-center">
        {/* Center Atom */}
        <div className="w-16 h-16 bg-white border-2 border-slate-800 rounded-full flex items-center justify-center text-2xl font-bold z-10">
          {currentLevel.center}
        </div>

        {/* Clickable Slots (Top, Bottom, Left, Right of center) */}
        {/* Only show slots that are NOT bonds? For simplicity, let's assume Bonds are fixed diagonal/sides */}
        
        {/* Top Slot */}
        <button 
          onClick={() => toggleSlot(0)}
          className={`absolute top-16 left-1/2 -translate-x-1/2 w-10 h-8 rounded-lg flex items-center justify-center border-2 border-dashed transition-all ${slots[0] ? 'border-red-500 bg-red-100' : 'border-slate-300 hover:bg-slate-100'}`}
        >
          {slots[0] && <div className="flex gap-1"><div className="w-2 h-2 bg-red-500 rounded-full"></div><div className="w-2 h-2 bg-red-500 rounded-full"></div></div>}
        </button>
        {/* Bottom Slot */}
        <button 
           onClick={() => toggleSlot(1)}
           className={`absolute bottom-16 left-1/2 -translate-x-1/2 w-10 h-8 rounded-lg flex items-center justify-center border-2 border-dashed transition-all ${slots[1] ? 'border-red-500 bg-red-100' : 'border-slate-300 hover:bg-slate-100'}`}
        >
          {slots[1] && <div className="flex gap-1"><div className="w-2 h-2 bg-red-500 rounded-full"></div><div className="w-2 h-2 bg-red-500 rounded-full"></div></div>}
        </button>

        {/* Visual Bonds (Static for context) */}
        {currentLevel.name === "H₂O" && (
          <>
            <div className="absolute bottom-8 left-8 w-10 h-10 bg-blue-100 text-blue-800 rounded-full flex items-center justify-center font-bold">H</div>
            <div className="absolute bottom-8 right-8 w-10 h-10 bg-blue-100 text-blue-800 rounded-full flex items-center justify-center font-bold">H</div>
            <div className="absolute w-1 h-16 bg-slate-300 transform rotate-45 bottom-12 right-12 -z-0"></div>
            <div className="absolute w-1 h-16 bg-slate-300 transform -rotate-45 bottom-12 left-12 -z-0"></div>
          </>
        )}
        {currentLevel.name === "NH₃" && (
           <>
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 w-10 h-10 bg-blue-100 text-blue-800 rounded-full flex items-center justify-center font-bold">H</div>
            <div className="absolute bottom-12 left-4 w-10 h-10 bg-blue-100 text-blue-800 rounded-full flex items-center justify-center font-bold">H</div>
            <div className="absolute bottom-12 right-4 w-10 h-10 bg-blue-100 text-blue-800 rounded-full flex items-center justify-center font-bold">H</div>
           </>
        )}

      </div>

      {!submitted ? (
        <button onClick={check} className="bg-teal-600 text-white px-8 py-3 rounded-full font-bold shadow-lg hover:bg-teal-700 transition-transform hover:scale-105">
          Cek Struktur
        </button>
      ) : (
        <div className="text-center animate-fadeIn">
          <p className={`font-bold mb-3 ${msg.includes('Hebat') ? 'text-green-600' : 'text-orange-600'}`}>{msg}</p>
          <button onClick={next} className="bg-slate-800 text-white px-6 py-2 rounded-lg font-bold text-sm">
            Soal Berikutnya
          </button>
        </div>
      )}
    </div>
  );
};

// Game 3: Benar atau Mitos
const GameFactMyth = ({ onScore }: { onScore: (points: number) => void }) => {
  const [idx, setIdx] = useState(0);
  const [feedback, setFeedback] = useState<string | null>(null);

  const q = GAME_3_DATA[idx];

  const answer = (choice: boolean) => {
    if (feedback) return;
    const correct = choice === q.isFact;
    if (correct) onScore(100);
    setFeedback(correct ? "Tepat! " + q.explanation : "Ups! " + q.explanation);
  };

  const next = () => {
    setFeedback(null);
    setIdx((prev) => (prev + 1) % GAME_3_DATA.length);
  };

  return (
    <div className="max-w-md mx-auto text-center">
      <h3 className="text-xl font-bold text-slate-700 mb-6">Benar atau Mitos?</h3>
      
      <div className="bg-orange-50 border-2 border-orange-200 p-6 rounded-2xl mb-8 min-h-[160px] flex items-center justify-center">
        <p className="text-lg font-medium text-slate-800 leading-relaxed">"{q.text}"</p>
      </div>

      {!feedback ? (
        <div className="flex gap-4 justify-center">
          <button onClick={() => answer(true)} className="bg-teal-500 hover:bg-teal-600 text-white py-3 px-8 rounded-xl font-bold shadow-md w-32">
            Benar
          </button>
          <button onClick={() => answer(false)} className="bg-pink-500 hover:bg-pink-600 text-white py-3 px-8 rounded-xl font-bold shadow-md w-32">
            Mitos
          </button>
        </div>
      ) : (
        <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm">
          <p className="mb-4 text-slate-800">{feedback}</p>
          <button onClick={next} className="text-teal-600 font-bold hover:underline">
            Lanjut
          </button>
        </div>
      )}
    </div>
  );
};

// Game 4: Tantangan Bertingkat (Progressive Wrapper)
const GameChallenge = ({ onScore }: { onScore: (points: number) => void }) => {
  const [level, setLevel] = useState(1);
  const [progress, setProgress] = useState(0); // 0-100 inside a level

  // Mock progression logic
  const completeLevel = () => {
    if (level < 3) {
      setLevel(prev => prev + 1);
      setProgress(0);
      onScore(500); // Level up bonus
    } else {
      setProgress(100);
      onScore(1000); // Game finish bonus
    }
  };

  const renderContent = () => {
    if (level === 1) {
      return (
        <div className="text-center">
          <h4 className="font-bold text-teal-700 mb-2">Level 1: Dasar Ikatan</h4>
          <p className="text-sm text-slate-500 mb-4">Selesaikan tantangan tebak ikatan untuk lanjut.</p>
          <GameGuessBond onScore={(pts) => { onScore(pts); setProgress(prev => Math.min(prev + 34, 100)); }} />
          {progress >= 100 && (
             <button onClick={completeLevel} className="mt-4 bg-yellow-400 text-yellow-900 px-6 py-2 rounded-full font-bold animate-bounce">
               Buka Level 2 🔓
             </button>
          )}
        </div>
      );
    }
    if (level === 2) {
      return (
        <div className="text-center">
          <h4 className="font-bold text-teal-700 mb-2">Level 2: Arsitek Molekul</h4>
          <p className="text-sm text-slate-500 mb-4">Susun struktur elektron dengan benar.</p>
          <GameLewisBuilder onScore={(pts) => { onScore(pts); setProgress(prev => Math.min(prev + 50, 100)); }} />
          {progress >= 100 && (
             <button onClick={completeLevel} className="mt-4 bg-yellow-400 text-yellow-900 px-6 py-2 rounded-full font-bold animate-bounce">
               Buka Level 3 🔓
             </button>
          )}
        </div>
      );
    }
    return (
      <div className="text-center py-10">
        <div className="inline-block p-6 bg-yellow-100 rounded-full mb-4">
            <Trophy className="w-16 h-16 text-yellow-600" />
        </div>
        <h3 className="text-2xl font-bold text-slate-800 mb-2">KAMU JUARA KIMIA!</h3>
        <p className="text-slate-600">Semua level telah diselesaikan.</p>
      </div>
    );
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6 bg-slate-100 p-3 rounded-lg">
         <span className="font-bold text-slate-700">Level {level}/3</span>
         <div className="w-32 h-3 bg-slate-300 rounded-full overflow-hidden">
            <div className="h-full bg-teal-500 transition-all duration-500" style={{ width: `${progress}%` }}></div>
         </div>
      </div>
      {renderContent()}
    </div>
  );
};

// --- MAIN COMPONENT ---

export const EducationalGame = () => {
  const [activeGame, setActiveGame] = useState<number | null>(null);
  const [score, setScore] = useState(0);

  const addScore = (points: number) => {
    setScore(prev => prev + points);
  };

  const resetGame = () => {
    if(confirm("Yakin ingin kembali ke menu? Skor akan disimpan tapi progres game direset.")) {
        setActiveGame(null);
    }
  };

  return (
    <section className="my-12 scroll-mt-20" id="game">
      {/* Header */}
      <div className="bg-gradient-to-r from-violet-600 to-indigo-600 p-8 rounded-t-3xl text-white shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-10 opacity-10 transform rotate-12">
            <Gamepad2 size={120} />
        </div>
        
        <div className="relative z-10 flex flex-col md:flex-row md:justify-between md:items-center gap-6">
          <div>
            <h2 className="text-3xl font-black tracking-tight flex items-center gap-3">
              <Gamepad2 className="text-yellow-300 animate-pulse" />
              Arena Kovalen
            </h2>
            <p className="text-violet-200 mt-1 font-medium">Mainkan, Pahami, dan Jadilah Juara!</p>
          </div>
          <ScoreBoard score={score} />
        </div>
      </div>

      <div className="bg-white min-h-[500px] border border-slate-200 border-t-0 rounded-b-3xl p-6 md:p-8">
        {!activeGame ? (
          // MENU
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <button onClick={() => setActiveGame(1)} className="group relative p-6 bg-blue-50 rounded-2xl border-2 border-blue-100 hover:border-blue-400 transition-all hover:-translate-y-1 text-left">
              <div className="bg-blue-500 w-12 h-12 rounded-xl flex items-center justify-center text-white mb-4 shadow-lg group-hover:scale-110 transition-transform">
                <HelpCircle />
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-1">Tebak Ikatan</h3>
              <p className="text-sm text-slate-500">Kenali jenis ikatan tunggal, rangkap 2, atau 3.</p>
            </button>

            <button onClick={() => setActiveGame(2)} className="group relative p-6 bg-teal-50 rounded-2xl border-2 border-teal-100 hover:border-teal-400 transition-all hover:-translate-y-1 text-left">
              <div className="bg-teal-500 w-12 h-12 rounded-xl flex items-center justify-center text-white mb-4 shadow-lg group-hover:scale-110 transition-transform">
                <Brain />
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-1">Arsitek Lewis</h3>
              <p className="text-sm text-slate-500">Lengkapi elektron bebas pada struktur molekul.</p>
            </button>

            <button onClick={() => setActiveGame(3)} className="group relative p-6 bg-orange-50 rounded-2xl border-2 border-orange-100 hover:border-orange-400 transition-all hover:-translate-y-1 text-left">
              <div className="bg-orange-500 w-12 h-12 rounded-xl flex items-center justify-center text-white mb-4 shadow-lg group-hover:scale-110 transition-transform">
                <Zap />
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-1">Benar atau Mitos</h3>
              <p className="text-sm text-slate-500">Uji pemahamanmu dan hindari miskonsepsi.</p>
            </button>

            <button onClick={() => setActiveGame(4)} className="group relative p-6 bg-purple-50 rounded-2xl border-2 border-purple-100 hover:border-purple-400 transition-all hover:-translate-y-1 text-left">
              <div className="bg-purple-500 w-12 h-12 rounded-xl flex items-center justify-center text-white mb-4 shadow-lg group-hover:scale-110 transition-transform">
                <Star />
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-1">Tantangan Level</h3>
              <p className="text-sm text-slate-500">Selesaikan misi bertingkat untuk bonus skor!</p>
            </button>
          </div>
        ) : (
          // GAME AREA
          <div className="animate-fadeIn">
            <button onClick={resetGame} className="mb-6 flex items-center gap-2 text-slate-500 hover:text-slate-800 font-bold text-sm">
              <RotateCcw size={16} /> Kembali ke Menu
            </button>
            
            {activeGame === 1 && <GameGuessBond onScore={addScore} />}
            {activeGame === 2 && <GameLewisBuilder onScore={addScore} />}
            {activeGame === 3 && <GameFactMyth onScore={addScore} />}
            {activeGame === 4 && <GameChallenge onScore={addScore} />}
          </div>
        )}
      </div>
    </section>
  );
};